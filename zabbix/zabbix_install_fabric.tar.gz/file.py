#!/usr/bin/env python
#coding:utf8

import os

f=open("hosts.txt","r")
hlist=[]
Flag=True
while Flag:
    data = f.readline().replace('\n','')
#    print(data)
    hlist.append(data)
    if f.tell() == os.path.getsize('hosts.txt'):
        Flag = False
        f.close()

