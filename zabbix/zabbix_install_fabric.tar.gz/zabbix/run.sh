#!/bin/bash
#
Zabbix_exe='/usr/local'
Zabbix_conf='/usr/local/zabbix/etc/zabbix_agentd.conf'
function start(){
 "$Zabbix_exe"/zabbix/sbin/zabbix_agentd -c $Zabbix_conf
}

function stop(){
 cat /tmp/zabbix_agentd.pid|xargs kill
}

function status(){
if [ -f /tmp/zabbix_agentd.pid ];then
   echo "Running..."
else
   echo "Stoped..."
fi
}

case $1 in
start)
  start
;;
stop)
  stop
;;
status)
  status
;;
*)
 echo "Usage:start|stop|satus"
esac

