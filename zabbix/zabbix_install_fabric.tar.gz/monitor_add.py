#!/usr/bin/env python
#coding:utf8

from fabric.api import *
from fabric.colors import *
from fabric.contrib.console import confirm
import os
import sys
import io
from file import hlist
import socket


env.hosts = hlist
env.warn_only = True
env.passwords={}


# The relate Dirs
# Local_dir Need the fabfile script present and other file
#Local_dir = '.'
Remote_dir = '/data'

#Package name
Exe_package_name = 'zabbix-3.0.tar.gz'
Src_package_name = 'zabbix-server.tar.gz'
Src_un_tar_name = 'zabbix-3.0.17'

#Source install Path
Src_install_dir = "/usr/local/zabbix/"

#Conf Path
Exe_conf_dir= os.path.join(Remote_dir,'zabbix/conf/zabbix_agentd.conf')
Src_conf_dir= os.path.join(Src_install_dir,'etc/zabbix_agentd.conf') 



# Tar packege put place
Exe_package_path = os.path.join(Remote_dir,Exe_package_name)
Src_package_path = os.path.join(Remote_dir,Src_package_name)


# Zabbix_conf Change 
Server="127.0.0.2"
ServerActive="127.0.0.2"
HostMetadata="Linux"


#*************************************************************************************************************************
#-------------------------------------------------------------------------------------------------------------------------
#*************************************************************************************************************************


def get_ip():
    try:
        s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(('8.8.8.8',80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip


# This function use to package file.
@runs_once
def pack():
    local("""rm -f %s"""%Exe_package_name)
    local("""tar -zcvf %s  --exclude='hosts.txt' --exclude='*.tar.gz' --exclude='*.py' --exclude='*.pyc'  . """%Exe_package_name)


# The function is Trans tar file to remote host.
def Tar_assit(local_package_path=None,remote_package_path=None):
    with cd(Remote_dir):
        run("""rm -rf zabbix* """)
        try:
            put(local_package_path,remote_package_path)
        except Exception:
            print(red("Need tar pacage file in this current Directory."))
        run("""tar xfv %s"""%remote_package_path)
        run(""" rm -f %s""" %remote_package_path)
            

def User_assit():
    run("""a=`cat /etc/passwd|grep -w zabbix`;if [ -z "$a" ];then useradd zabbix;fi""")



def Conf_change(Conf_dir=None):
    run("""sed -i s/^Server=.*/"Server=%s/" %s """ %(Server,Conf_dir))
    run("""sed -i s/^ServerActive=.*/"ServerActive=%s/" %s """ %(ServerActive,Conf_dir))
    Hostname = prompt("Input Hostname about This Agent: ",default='Hostname')
    run("""sed -i s/^Hostname=.*/"Hostname=%s/" %s """ %(Hostname,Conf_dir))
    run("""sed -i "s/^# HostMetadata=.*/HostMetadata=%s/" %s """ %(HostMetadata,Conf_dir))

def Src_build():
    with cd(os.path.join(Remote_dir,Src_un_tar_name)):
        run("""mkdir %s"""%Src_install_dir)
        run("""yum -y makecache fast;yum -y install gcc gcc-c++""")
        run("""./configure --prefix=%s --enable-agent"""%Src_install_dir)
        run("make")
        run(" make install")

def Systemd_conf(method=None):
    run("""a=`cat /etc/centos-release`;echo ${#a}""")
    Release = prompt("Is Centos 7 ?[6|7]",default='7')
    if Release == '7':
        print(method)
        if method == 's':
            run("""mv %s/zabbix_agent.service /usr/lib/systemd/system/ """%os.path.join(Remote_dir,Src_un_tar_name))
            run("""systemctl daemon-reload""")
            run("""systemctl start zabbix_agent""")
            run("""rm -rf %s"""%os.path.join(Remote_dir,Src_un_tar_name))
        elif method == 'e':
#            run("""sed -i s@'^EnvironmentFile=.*'@EnvironmentFile=%s@  %s/zabbix_agent.service"""%(Exe_conf_dir,os.path.dirname(Exe_conf_dir)))
            run("""sed -i s#'^ExecStart=.*'#ExecStart=@%s -c %s#  %s/zabbix_agent.service"""%(os.path.join(Remote_dir,'zabbix/sbin/zabbix_agentd'),Exe_conf_dir,os.path.dirname(Exe_conf_dir)))
            run("""mv %s/zabbix_agent.service /usr/lib/systemd/system/ """%os.path.dirname(Exe_conf_dir))
            run("""systemctl daemon-reload""")
            run("""systemctl start zabbix_agent""")
            run("rm -f %s/zabbix/zabbix_agentd"%Remote_dir)
    elif Release == '6':
        if method == 's':
            run("""mv %s/zabbix_agentd  %s """%(os.path.join(Remote_dir,Src_un_tar_name),"/etc/init.d/"))
            run("""chkconfig --add zabbix_agentd;chkconfig zabbix_agentd on;chkconfig --list|grep zabbix_agentd;service zabbix_agentd start """)
            run("""rm -rf %s"""%os.path.join(Remote_dir,Src_un_tar_name))
        elif method == 'e':
            run("""sed -i s@^Zabbix_exe.*@Zabbix_exe=%s@ %s"""%(Remote_dir,os.path.join(Remote_dir,'zabbix/run.sh')))
            run("""sed -i s@^Zabbix_conf.*@Zabbix_conf=%s@ %s"""%(Exe_conf_dir,os.path.join(Remote_dir,'zabbix/run.sh')))

            run("""sed -i 's@^ZABBIX_BIN=.*@ZABBIX_BIN=\"%s -c %s\"@' %s"""%(os.path.join(Remote_dir,'zabbix/sbin/zabbix_agentd'),Exe_conf_dir,os.path.join(Remote_dir,'zabbix/zabbix_agentd')))
            run("""mv %s/zabbix_agentd  %s """%(os.path.join(Remote_dir,'zabbix'),"/etc/init.d/"))
            run("""chkconfig --add zabbix_agentd;chkconfig zabbix_agentd on;chkconfig --list|grep zabbix_agentd;service zabbix_agentd start """)
        





@task
def go():
    pack()
    Method = prompt("Your is Use Exec Or Source ?[e|s]: ",default='e')
    if Method == 'e':
        Tar_assit(local_package_path=Exe_package_name ,remote_package_path=Exe_package_path)
        Conf_change(Conf_dir=Exe_conf_dir)
        User_assit()
        Systemd_conf(method=Method)
    elif Method == 's':
        Tar_assit(local_package_path=Src_package_name,remote_package_path=Src_package_path)
        Src_build()
        Conf_change(Conf_dir=Src_conf_dir)
        User_assit()
        Systemd_conf(method=Method)
